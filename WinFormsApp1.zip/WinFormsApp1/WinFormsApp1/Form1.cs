using System.Diagnostics.Eventing.Reader;

namespace WinFormsApp1
{
    public partial class numbersListBox : Form
    {
        public numbersListBox()
        {
            InitializeComponent();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text Files|*.txt";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    listBox1.Items.Clear();
                    List<int> allNumbers = new List<int>();
                    String filePath = openFileDialog.FileName;
                    string[] lines = File.ReadAllLines(filePath);

                    foreach (string line in lines)
                    {
                        string upperCaseLine = line.ToUpper();
                        if (int.TryParse(upperCaseLine, out int number))
                        {
                            listBox1.Items.Add(number);
                            allNumbers.Add(number);
                        }
                        else if (ContainsOnlyValidRomanNumerals(upperCaseLine))
                        {
                            int romanNumber = RomanToIntegers(upperCaseLine);


                            listBox1.Items.Add(romanNumber);
                            allNumbers.Add(romanNumber);

                        }
                    }
                    int total = allNumbers.Sum();
                    double average = total / (double)allNumbers.Count();
                    totalLabel1.Text = $"{total}";
                    averageLabel.Text = $"{average}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occured: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
        private bool ContainsOnlyValidRomanNumerals(string S)
        {
            string validRomanNumerals = "IVXLCDM";
            foreach (char c in S)
            {
                if (!validRomanNumerals.Contains(c))
                {
                    return false;
                }
            }
            return true;
        }
        private int RomanToIntegers(string s)
        {
            Dictionary<char, int> romanValues = new Dictionary<char, int>
        {
            { 'I', 1},
            { 'V', 5},
            { 'X', 10},
            { 'L', 50},
            { 'C', 100},
            { 'D', 500},
            { 'M', 1000}
        };
            int result = 0;

            for (int i = 0; i < s.Length; i++)
            {
                if (romanValues.ContainsKey(s[i]))
                {

                    if (i < s.Length - 1 && romanValues[s[i]] < romanValues[s[i + 1]])
                    {
                        result -= romanValues[s[i]];
                    }
                    else
                    {
                        result += romanValues[s[i]];
                    }
                }
                else
                {
                    return -1;
                }


            }
            return result;
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files|*.txt";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string filePath = saveFileDialog.FileName;

                    using (StreamWriter writer = new StreamWriter(filePath))
                    {
                        foreach (var item in listBox1.Items)
                        {
                            writer.WriteLine(item.ToString());
                        }
                    }
                    MessageBox.Show("File saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occured while saving the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void totallabel_Click(object sender, EventArgs e)
        {

        }

        private void avergeLabel_Click(object sender, EventArgs e)
        {

        }
    }



}