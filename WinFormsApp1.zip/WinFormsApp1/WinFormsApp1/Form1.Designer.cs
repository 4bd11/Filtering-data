﻿namespace WinFormsApp1
{
    partial class numbersListBox
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            openButton = new Button();
            saveButton = new Button();
            totallabel = new Label();
            label2 = new Label();
            totalLabel1 = new Label();
            averageLabel = new Label();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(68, 59);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(170, 214);
            listBox1.TabIndex = 0;
            // 
            // openButton
            // 
            openButton.Location = new Point(308, 255);
            openButton.Name = "openButton";
            openButton.Size = new Size(75, 23);
            openButton.TabIndex = 1;
            openButton.Text = "Open";
            openButton.UseVisualStyleBackColor = true;
            openButton.Click += openButton_Click;
            // 
            // saveButton
            // 
            saveButton.Location = new Point(444, 255);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(75, 23);
            saveButton.TabIndex = 2;
            saveButton.Text = "Save as";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += saveButton_Click;
            // 
            // totallabel
            // 
            totallabel.AutoSize = true;
            totallabel.Location = new Point(335, 115);
            totallabel.Name = "totallabel";
            totallabel.Size = new Size(35, 15);
            totallabel.TabIndex = 3;
            totallabel.Text = "Total:";
            totallabel.Click += totallabel_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(335, 155);
            label2.Name = "label2";
            label2.Size = new Size(53, 15);
            label2.TabIndex = 4;
            label2.Text = "Average:";
            // 
            // totalLabel1
            // 
            totalLabel1.AutoSize = true;
            totalLabel1.BackColor = SystemColors.ControlDarkDark;
            totalLabel1.BorderStyle = BorderStyle.FixedSingle;
            totalLabel1.ForeColor = SystemColors.ControlText;
            totalLabel1.Location = new Point(394, 115);
            totalLabel1.Name = "totalLabel1";
            totalLabel1.Size = new Size(24, 17);
            totalLabel1.TabIndex = 5;
            totalLabel1.Text = "0.0";
            // 
            // averageLabel
            // 
            averageLabel.AutoSize = true;
            averageLabel.BackColor = SystemColors.ControlDarkDark;
            averageLabel.BorderStyle = BorderStyle.FixedSingle;
            averageLabel.Location = new Point(394, 155);
            averageLabel.Name = "averageLabel";
            averageLabel.Size = new Size(24, 17);
            averageLabel.TabIndex = 6;
            averageLabel.Text = "0.0";
            averageLabel.Click += avergeLabel_Click;
            // 
            // numbersListBox
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(averageLabel);
            Controls.Add(totalLabel1);
            Controls.Add(label2);
            Controls.Add(totallabel);
            Controls.Add(saveButton);
            Controls.Add(openButton);
            Controls.Add(listBox1);
            Name = "numbersListBox";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private Button openButton;
        private Button saveButton;
        private Label totallabel;
        private Label label2;
        private Label totalLabel1;
        private Label averageLabel;
    }
}